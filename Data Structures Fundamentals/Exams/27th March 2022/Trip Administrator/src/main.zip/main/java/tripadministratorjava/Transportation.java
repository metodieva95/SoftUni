package tripadministratorjava;

public enum Transportation {
    BUS,
    PLANE,
    NONE
}
